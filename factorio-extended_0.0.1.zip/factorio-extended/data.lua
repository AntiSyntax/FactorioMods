require("prototypes.assemblers")
require("prototypes.item-groups")